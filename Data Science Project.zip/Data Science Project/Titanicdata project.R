Titanic <- read.csv("H:/AIUB/Data Science/Mid Project/Titanic.csv")
View(Titanic)

names(Titanic)
str(Titanic)



print(Titanic)


sum(is.na(Titanic))


meanage <- mean(Titanic$age, na.rm = TRUE)
print(meanage)

Titanic[is.na(Titanic$age), "age"] <- meanage
print(Titanic)


Titanic[Titanic == ""] <- NA

Titanic <-na.omit(Titanic)


unique(Titanic$who)


Titanic$who <- ifelse(Titanic$who == "mannn", "man", 
                      ifelse(Titanic$who == "womannn", "woman", 
ifelse(Titanic$who == "womann", "woman", Titanic$who)))




boxplot(Titanic$age, main = "age")

outliers <- boxplot.stats(Titanic$age)$out

print(outliers)


Titanic<- Titanic[!Titanic$age %in% outliers, ]
print(Titanic)

summary(Titanic)


s<-Titanic$fare
sd(s)


s<-Titanic$age
sd(s)


hist(Titanic$age, main = "Histogram of age", xlab = "age", ylab = "Frequency")

hist(Titanic$fare, main = "Histogram of fare", xlab = "fare", ylab = "Frequency")

hist(Titanic$age, main = "Histogram of sibsp", xlab = "sibsp", ylab = "Frequency")

hist(Titanic$age, main = "Histogram of parch", xlab = "parch", ylab = "Frequency")







