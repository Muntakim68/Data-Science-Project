COVID19 <- read.csv("H:/AIUB/Data Science/Final Project/COVID-19 Coronavirus.csv")
View(COVID19)

names(COVID19)
str(COVID19)

print(COVID19)


Other.names <- which(COVID19$Other.names == "United Kingdom")
COVID19$Other.names[Other.names] <- "Iran"


COVID19$Other.names[COVID19$Other.names == ""] <- NA


sum(is.na(COVID19))


COVID19 <- COVID19[!is.na(COVID19$Other.names), ]




COVID19$Country <- as.numeric(factor(COVID19$Country, levels = unique(COVID19$Country)))

COVID19$Other.names <- as.numeric(factor(COVID19$Other.names, levels = unique(COVID19$Other.names)))

COVID19$ISO.3166.1.alpha.3.CODE <- as.numeric(factor(COVID19$ISO.3166.1.alpha.3.CODE , levels = unique(COVID19$ISO.3166.1.alpha.3.CODE )))

COVID19$Continent <- as.numeric(factor(COVID19$Continent , levels = unique(COVID19$Continent )))




mean_values <- colMeans(COVID19)
std_dev_values <- apply(COVID19, 2, sd)
z_scores <- scale(COVID19, center = mean_values, scale = std_dev_values)
print(z_scores)



correlation <- cor(COVID19$Country, COVID19$Population)
print(correlation)
correlation <- cor(COVID19$Country, COVID19$ISO.3166.1.alpha.3.CODE)
print(correlation)
correlation <- cor(COVID19$Country, COVID19$Other.names)
print(correlation)
correlation <- cor(COVID19$Other.names, COVID19$Continent)
print(correlation)
correlation <- cor(COVID19$Country, COVID19$ Total.Cases)
print(correlation)
correlation <- cor(COVID19$Country, COVID19$Total.Deaths )
print(correlation)
correlation <- cor(COVID19$Country, COVID19$Tot.Cases..1M.pop )
print(correlation)
correlation <- cor(COVID19$Country, COVID19$Tot.Deaths.1M.pop )
print(correlation)
correlation <- cor(COVID19$Country, COVID19$Death.percentage )
print(correlation)


cor_matrix <- cor(COVID19)
corrplot(cor_matrix, method = "color")
print(cor_matrix)




set.seed(123)

COVID <- sample(nrow(COVID19), 0.7 * nrow(COVID19))  
train_data <- COVID19[COVID, ]
View(train_data)
test_data <- COVID19[-COVID, ]
View(test_data)

dim(train_data)
dim(test_data)
dim(COVID19)

selected_data <- COVID19 %>%
  select(Country, Other.names, ISO.3166.1.alpha.3.CODE,Population, Continent, Total.Cases, Total.Deaths, Tot.Cases..1M.pop, Tot.Deaths.1M.pop, Death.percentage)


X <- COVID19 %>%
  select(-Death.percentage)

y <- COVID19$Death.percentage

k <- 3
knn_model <- knn(train = X, test = X, cl = y, k = k)
print(knn_model)
y_test <- test_data$Death.percentage
knn_predictions <- knn(train = train_data, test = test_data, cl = train_data$Death.percentage, k = k)



accuracy <- sum(knn_predictions == y_test) / length(y_test)
cat("Predictive accuracy:", round(accuracy * 100, 2), "%\n")




knn_predictions <- knn(train = train_data[, -which(names(train_data) == "Death.percentage")], 
                       test = test_data[, -which(names(test_data) == "Death.percentage")],      
                       cl = train_data$Death.percentage,  
                       k = k)  
print("KNN Predicted Values:")
print(knn_predictions)



confusion_matrix <- table(Actual = y_test, Predicted = knn_predictions)
print(confusion_matrix)


precision <- confusion_matrix[2, 2] / sum(confusion_matrix[, 2])
cat("Precision:", round(precision, 4), "\n")


recall <- confusion_matrix[2, 2] / sum(confusion_matrix[2, ])
cat("Recall (Sensitivity):", round(recall, 4), "\n")






install.packages("class")
library(class)

install.packages("corrplot")
library(corrplot)

install.packages("ggplot2")
library(ggplot2)

install.packages("caret")
library(caret)

install.packages("dplyr")
library(dplyr)
